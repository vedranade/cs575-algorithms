1. Compile the file homework4.cpp and run the executable
2. A menu will be printed which will allow you to run a particular homework question
