Steps to run the two questions from the programming section:
1. Compile the file AlgorithmsHW6.cpp using a C++ compiler.
2. Upon execution, a console menu will be displayed
3. Hit the appropriate choice. The program will accept the different vertices and the weights of edges between them as input.
